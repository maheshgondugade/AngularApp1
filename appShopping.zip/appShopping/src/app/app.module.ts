import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { CartViewComponent } from './cart-view/cart-view.component';
import { CheckoutFormComponent } from './checkout-form/checkout-form.component';
import { CheckoutViewComponent } from './checkout-view/checkout-view.component';
import { JumbotronComponent } from './jumbotron/jumbotron.component';
import { LicensePlateComponent } from './license-plate/license-plate.component';
import { NavigationComponent } from './navigation/navigation.component';
import { StoreViewComponent } from './store-view/store-view.component';
import { CreditCardImageDirective } from './credit-card-image.directive';

@NgModule({
  declarations: [
    AppComponent,
    CartViewComponent,
    CheckoutFormComponent,
    CheckoutViewComponent,
    JumbotronComponent,
    LicensePlateComponent,
    NavigationComponent,
    StoreViewComponent,
    CreditCardImageDirective
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
