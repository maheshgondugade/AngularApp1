import { Component } from '@angular/core';
import { LicensePlate } from './license-plate';
import { LisensePlateService } from './lisense-plate.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

    licensePlates: LicensePlate[];

    constructor(private service: LisensePlateService){
      service.getAllPlates().subscribe(plates=> this.licensePlates = plates);
    }

    addToCart(event: LicensePlate) : void{
      alert(`License plate '${event.title}' added to cart`);
    }
}
