import { TestBed } from '@angular/core/testing';

import { LisensePlateService } from './lisense-plate.service';

describe('LisensePlateService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LisensePlateService = TestBed.get(LisensePlateService);
    expect(service).toBeTruthy();
  });
});
