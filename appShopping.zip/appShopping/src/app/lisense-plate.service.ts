import { Injectable } from '@angular/core';
import { HttpClient } from 'selenium-webdriver/http';
import { observable, Observable } from 'rxjs';
import { LicensePlate } from './license-plate';

@Injectable()
export class LisensePlateService {

  constructor(private http: HttpClient) {
  }

  getAllPlates(): Observable<LicensePlate[]>{
    return this.http.get<LicensePlate[]>('http://localhost:8000/data');
  }

}
