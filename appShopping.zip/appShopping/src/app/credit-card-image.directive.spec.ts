import { CreditCardImageDirective } from './credit-card-image.directive';

describe('CreditCardImageDirective', () => {
  it('should create an instance', () => {
    const directive = new CreditCardImageDirective();
    expect(directive).toBeTruthy();
  });
});
