import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { LicensePlate } from '../license-plate';
import { LisensePlateService } from '../lisense-plate.service'
import { CartService } from '../cart.service';

@Component({
  selector: 'app-store-view',
  templateUrl: './store-view.component.html',
  styleUrls: ['./store-view.component.css']
})
export class StoreViewComponent implements OnInit {

  ngOnInit() {
  }
  
  plates: Observable<LicensePlate[]>;

  constructor(private plateService: LisensePlateService, private cartService: CartService) {
    this.plates = plateService.getAllPlates();
  }

  addToCart(plate: LicensePlate) {
    this.cartService.addToCart(plate)
      .subscribe(done => alert(`Plate '${plate.title}' added to cart`));
  }

}



